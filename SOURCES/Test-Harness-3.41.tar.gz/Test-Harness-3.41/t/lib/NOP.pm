package NOP;

# Do nothing much

sub new { bless {}, shift }

1;
