#ifndef MPU_GMPAKS_H
#define MPU_GMPAKS_H

#include <gmp.h>
#include "ptypes.h"

extern int  is_aks_prime(mpz_t n);

#endif
